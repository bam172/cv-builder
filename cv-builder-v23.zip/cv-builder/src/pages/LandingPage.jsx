import { useNavigate } from 'react-router-dom'
import { FileText, Upload, Sparkles, ChevronRight } from 'lucide-react'
import { useCVStore } from '../store/cvStore'
import { useCallback, useState } from 'react'
import { useDropzone } from 'react-dropzone'

export default function LandingPage() {
  const navigate = useNavigate()
  const updateCV = useCVStore((s) => s.updateCV)
  const [loading, setLoading] = useState(false)
  const [apiKey, setApiKey] = useState(localStorage.getItem('anthropic_key') || '')
  const [showKey, setShowKey] = useState(false)

  const onDrop = useCallback(
    async (acceptedFiles) => {
      const file = acceptedFiles[0]
      if (!file) return

      if (!apiKey.trim()) {
        alert('Masukkan Anthropic API Key terlebih dahulu untuk fitur AI ekstraksi.')
        return
      }

      setLoading(true)
      localStorage.setItem('anthropic_key', apiKey)

      try {
        // Convert PDF to base64
        const base64 = await new Promise((res, rej) => {
          const r = new FileReader()
          r.onload = () => res(r.result.split(',')[1])
          r.onerror = rej
          r.readAsDataURL(file)
        })

        const response = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: 'claude-sonnet-4-20250514',
            max_tokens: 2000,
            messages: [
              {
                role: 'user',
                content: [
                  {
                    type: 'document',
                    source: { type: 'base64', media_type: 'application/pdf', data: base64 },
                  },
                  {
                    type: 'text',
                    text: `Ekstrak semua data dari CV/resume ini dan kembalikan HANYA sebagai JSON valid (tanpa markdown, tanpa penjelasan) dengan struktur berikut:
{
  "name": "nama lengkap",
  "job_title": "jabatan/title",
  "email": "email",
  "phone": "nomor telepon",
  "address": "alamat",
  "summary": "ringkasan profesional",
  "skills": [{"id": 1, "name": "nama skill", "category": "kategori skill"}],
  "experience": [{"id": 1, "position": "jabatan", "company": "perusahaan", "startDate": "bulan tahun", "endDate": "bulan tahun atau Present", "responsibilities": ["tanggung jawab 1", "tanggung jawab 2"]}],
  "education": [{"id": 1, "degree": "gelar", "institution": "institusi", "startDate": "", "endDate": "", "notes": ""}],
  "links": [{"id": 1, "label": "label", "url": "url"}]
}`,
                  },
                ],
              },
            ],
          }),
        })

        const data = await response.json()
        const text = data.content?.find((c) => c.type === 'text')?.text || ''
        const clean = text.replace(/```json|```/g, '').trim()
        const parsed = JSON.parse(clean)
        updateCV(parsed)
        navigate('/templates')
      } catch (err) {
        console.error(err)
        alert('Gagal mengekstrak CV. Pastikan API key valid dan file adalah PDF yang berisi teks.')
      } finally {
        setLoading(false)
      }
    },
    [apiKey, updateCV, navigate]
  )

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/pdf': ['.pdf'] },
    multiple: false,
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 flex flex-col items-center justify-center px-4 py-16">
      {/* Header */}
      <div className="text-center mb-14">
        <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 text-blue-300 text-sm px-4 py-1.5 rounded-full mb-6">
          <Sparkles size={14} />
          CV Builder + AI Extractor
        </div>
        <h1 className="text-5xl font-bold text-white mb-4 tracking-tight">
          Buat CV Profesional
          <span className="text-blue-400"> dalam Menit</span>
        </h1>
        <p className="text-slate-400 text-lg max-w-md mx-auto">
          Isi manual atau upload CV lama — AI akan mengekstrak datanya otomatis.
        </p>
      </div>

      {/* Cards */}
      <div className="grid md:grid-cols-2 gap-6 w-full max-w-3xl mb-10">
        {/* Manual */}
        <button
          onClick={() => navigate('/form')}
          className="group bg-white/5 border border-white/10 hover:border-blue-500/50 hover:bg-white/10 rounded-2xl p-8 text-left transition-all duration-200"
        >
          <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center mb-5">
            <FileText className="text-blue-400" size={24} />
          </div>
          <h2 className="text-white font-semibold text-xl mb-2">Isi Form Manual</h2>
          <p className="text-slate-400 text-sm leading-relaxed">
            Isi data profil, pengalaman, pendidikan, dan skill satu per satu. Cocok untuk CV baru.
          </p>
          <div className="flex items-center gap-1 text-blue-400 text-sm mt-5 group-hover:gap-2 transition-all">
            Mulai <ChevronRight size={16} />
          </div>
        </button>

        {/* AI Upload */}
        <div className="bg-white/5 border border-white/10 hover:border-teal-500/50 rounded-2xl p-8 transition-all duration-200">
          <div className="w-12 h-12 bg-teal-500/20 rounded-xl flex items-center justify-center mb-5">
            <Upload className="text-teal-400" size={24} />
          </div>
          <h2 className="text-white font-semibold text-xl mb-2">Upload CV PDF</h2>
          <p className="text-slate-400 text-sm leading-relaxed mb-4">
            Upload CV lama dalam format PDF. AI akan membaca dan mengisi form otomatis.
          </p>

          {/* API Key input */}
          <div className="mb-3">
            <label className="text-slate-400 text-xs mb-1 block">Anthropic API Key</label>
            <div className="flex gap-2">
              <input
                type={showKey ? 'text' : 'password'}
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="sk-ant-..."
                className="flex-1 bg-white/10 border border-white/10 text-white text-xs rounded-lg px-3 py-2 placeholder-slate-500 focus:outline-none focus:border-teal-500/50"
              />
              <button
                onClick={() => setShowKey(!showKey)}
                className="text-slate-400 text-xs px-2"
              >
                {showKey ? 'Hide' : 'Show'}
              </button>
            </div>
          </div>

          {/* Dropzone */}
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-xl p-5 text-center cursor-pointer transition-all ${
              isDragActive
                ? 'border-teal-400 bg-teal-500/10'
                : 'border-white/15 hover:border-teal-500/40 hover:bg-white/5'
            }`}
          >
            <input {...getInputProps()} />
            {loading ? (
              <div className="text-teal-400 text-sm">
                <div className="animate-spin w-5 h-5 border-2 border-teal-400 border-t-transparent rounded-full mx-auto mb-2" />
                AI sedang membaca CV...
              </div>
            ) : (
              <p className="text-slate-400 text-sm">
                {isDragActive ? 'Lepas file di sini...' : 'Drag & drop PDF atau klik untuk pilih'}
              </p>
            )}
          </div>
        </div>
      </div>

      <p className="text-slate-600 text-xs">
        Data tersimpan di browser. Tidak ada server yang menyimpan CV kamu.
      </p>
    </div>
  )
}
